"""
Data preprocessing script for GraphRec.
Reads .mat files (rating and trust data) and generates pickle files
with the same structure as the toy dataset.

The generated pickle file contains:
- history_u_lists: dict {user_id: [list of item_ids purchased/interacted]}
- history_ur_lists: dict {user_id: [list of rating indices for items in history_u_lists]}
- history_v_lists: dict {item_id: [list of user_ids who interacted with item]}
- history_vr_lists: dict {item_id: [list of rating indices for users in history_v_lists]}
- train_u, train_v, train_r: lists of user_ids, item_ids, ratings for training
- test_u, test_v, test_r: lists of user_ids, item_ids, ratings for testing
- social_adj_lists: dict {user_id: set of neighbor user_ids}
- ratings_list: dict {rating_value: rating_index}
"""

import scipy.io as sio
import numpy as np
import pickle
from collections import defaultdict
import random


def load_rating_file_as_matrix(rating_file_path):
    """
    Load rating data from .mat file.

    Args:
        rating_file_path: Path to the _rating_with_timestamp.mat file

    Returns:
        np.array: N x 6 array where columns are:
            0: user_id
            1: item_id
            2: category (not used)
            3: rating
            4: helpfulness
            5: timestamp
    """
    rating_data = sio.loadmat(rating_file_path)
    # Different datasets use different key names
    if 'rating' in rating_data:
        return rating_data['rating']
    elif 'rating_with_timestamp' in rating_data:
        return rating_data['rating_with_timestamp']
    else:
        # Find the first non-metadata key
        data_keys = [k for k in rating_data.keys() if not k.startswith('__')]
        if data_keys:
            return rating_data[data_keys[0]]
        raise KeyError("Could not find rating data in .mat file")


def load_trust_file_as_matrix(trust_file_path):
    """
    Load trust/social data from .mat file.

    Args:
        trust_file_path: Path to the _trust.mat file

    Returns:
        np.array: N x 2 array where columns are:
            0: user_id
            1: neighbor_user_id (user they trust/connected to)
    """
    trust_data = sio.loadmat(trust_file_path)
    return trust_data['trust']


def create_pickle_from_mat(rating_file_path,
                           trust_file_path,
                           output_pickle_path,
                           user_percentage=100.0,
                           train_split=0.8,
                           random_seed=42):
    """
    Read .mat files and generate pickle file with GraphRec data structure.

    Args:
        rating_file_path: Path to _rating_with_timestamp.mat file
        trust_file_path: Path to _trust.mat file
        output_pickle_path: Path where the output pickle file will be saved
        user_percentage: Percentage of users to include (0-100)
        train_split: Fraction of data to use for training (0-1)
                    The remaining data is split equally between validation and test
                    For example, train_split=0.8 means 80% train, 10% validation, 10% test
                    train_split=0.6 means 60% train, 20% validation, 20% test
        random_seed: Random seed for reproducibility

    Returns:
        dict: Statistics about the generated dataset
    """
    random.seed(random_seed)
    np.random.seed(random_seed)

    print(f"Loading rating data from {rating_file_path}...")
    rating_matrix = load_rating_file_as_matrix(rating_file_path)

    print(f"Loading trust data from {trust_file_path}...")
    trust_matrix = load_trust_file_as_matrix(trust_file_path)

    print(f"Rating matrix shape: {rating_matrix.shape}")
    print(f"Trust matrix shape: {trust_matrix.shape}")

    # Extract columns from rating matrix
    # Column 0: user_id, Column 1: item_id, Column 3: rating
    all_user_ids = rating_matrix[:, 0]
    all_item_ids = rating_matrix[:, 1]
    all_ratings = rating_matrix[:, 3]

    # Get unique users and items
    unique_users = np.unique(all_user_ids)
    unique_items = np.unique(all_item_ids)

    print(f"Total unique users: {len(unique_users)}")
    print(f"Total unique items: {len(unique_items)}")
    print(f"Total ratings: {len(all_ratings)}")

    # Sample users based on user_percentage
    num_users_to_sample = int(len(unique_users) * user_percentage / 100.0)
    sampled_users = np.random.choice(unique_users, size=num_users_to_sample, replace=False)

    print(f"Sampling {user_percentage}% of users: {num_users_to_sample} users")

    # Filter rating matrix to only include sampled users
    user_mask = np.isin(all_user_ids, sampled_users)
    filtered_user_ids = all_user_ids[user_mask]
    filtered_item_ids = all_item_ids[user_mask]
    filtered_ratings = all_ratings[user_mask]

    print(f"Ratings after user filtering: {len(filtered_ratings)}")

    # Create ratings_list (mapping from rating value to index)
    unique_ratings = sorted(set(filtered_ratings))
    ratings_list = {float(rating): idx for idx, rating in enumerate(unique_ratings)}

    print(f"Unique ratings found: {unique_ratings}")
    print(f"Ratings list mapping: {ratings_list}")

    # Convert ratings to indices
    rating_indices = np.array([ratings_list[float(r)] for r in filtered_ratings])

    # Split into train, validation, and test sets FIRST (before remapping)
    num_ratings = len(filtered_user_ids)
    indices = np.arange(num_ratings)
    np.random.shuffle(indices)

    train_size = int(num_ratings * train_split)
    remaining_size = num_ratings - train_size
    val_size = remaining_size // 2

    train_indices = indices[:train_size]
    val_indices = indices[train_size:train_size + val_size]
    test_indices = indices[train_size + val_size:]

    # Get train, validation, and test data with original IDs
    train_user_ids_orig = filtered_user_ids[train_indices]
    train_item_ids_orig = filtered_item_ids[train_indices]
    train_rating_indices = rating_indices[train_indices]

    val_user_ids_orig = filtered_user_ids[val_indices]
    val_item_ids_orig = filtered_item_ids[val_indices]
    val_rating_indices = rating_indices[val_indices]

    test_user_ids_orig = filtered_user_ids[test_indices]
    test_item_ids_orig = filtered_item_ids[test_indices]
    test_rating_indices = rating_indices[test_indices]

    # Create ID mappings based on TRAINING SET ONLY
    unique_train_users = np.unique(train_user_ids_orig)
    unique_train_items = np.unique(train_item_ids_orig)

    user_id_map = {old_id: new_id for new_id, old_id in enumerate(unique_train_users)}
    item_id_map = {old_id: new_id for new_id, old_id in enumerate(unique_train_items)}

    print(f"Users in training set: {len(unique_train_users)}")
    print(f"Items in training set: {len(unique_train_items)}")

    # Remap training set IDs
    train_u = [user_id_map[uid] for uid in train_user_ids_orig]
    train_v = [item_id_map[iid] for iid in train_item_ids_orig]
    train_r = train_rating_indices.tolist()

    # Remap validation set IDs (only include users/items that appear in training)
    val_u = []
    val_v = []
    val_r = []

    for uid, iid, r in zip(val_user_ids_orig, val_item_ids_orig, val_rating_indices):
        # Only include validation samples where both user and item appeared in training
        if uid in user_id_map and iid in item_id_map:
            val_u.append(user_id_map[uid])
            val_v.append(item_id_map[iid])
            val_r.append(r)

    # Remap test set IDs (only include users/items that appear in training)
    test_u = []
    test_v = []
    test_r = []

    for uid, iid, r in zip(test_user_ids_orig, test_item_ids_orig, test_rating_indices):
        # Only include test samples where both user and item appeared in training
        if uid in user_id_map and iid in item_id_map:
            test_u.append(user_id_map[uid])
            test_v.append(item_id_map[iid])
            test_r.append(r)

    print(f"Train set size: {len(train_u)}")
    print(f"Validation set size: {len(val_u)} (filtered to only include users/items from training)")
    print(f"Test set size: {len(test_u)} (filtered to only include users/items from training)")

    # Build history dictionaries from training set only
    history_u_lists = defaultdict(list)
    history_ur_lists = defaultdict(list)
    history_v_lists = defaultdict(list)
    history_vr_lists = defaultdict(list)

    for u, v, r in zip(train_u, train_v, train_r):
        history_u_lists[u].append(v)
        history_ur_lists[u].append(r)
        history_v_lists[v].append(u)
        history_vr_lists[v].append(r)

    print(f"Number of users with history: {len(history_u_lists)}")
    print(f"Number of items with history: {len(history_v_lists)}")

    # Build social adjacency lists from trust matrix
    social_adj_lists = defaultdict(set)

    trust_user1 = trust_matrix[:, 0]
    trust_user2 = trust_matrix[:, 1]

    # Filter to only include users that appear in the training set
    for u1, u2 in zip(trust_user1, trust_user2):
        # Convert to int to avoid type issues with numpy types
        u1 = int(u1)
        u2 = int(u2)

        # Only include edges where BOTH users are in the training set
        if u1 in user_id_map and u2 in user_id_map:
            # Remap to new user IDs
            new_u1 = user_id_map[u1]
            new_u2 = user_id_map[u2]
            social_adj_lists[new_u1].add(new_u2)
            # Add bidirectional edge (undirected graph)
            social_adj_lists[new_u2].add(new_u1)

    print(f"Number of users with social connections: {len(social_adj_lists)}")

    # Save to pickle file
    print(f"Saving to {output_pickle_path}...")
    data_to_save = (
        history_u_lists,
        history_ur_lists,
        history_v_lists,
        history_vr_lists,
        train_u,
        train_v,
        train_r,
        val_u,
        val_v,
        val_r,
        test_u,
        test_v,
        test_r,
        social_adj_lists,
        ratings_list
    )

    with open(output_pickle_path, 'wb') as f:
        pickle.dump(data_to_save, f)

    print("Done!")

    # Return statistics
    stats = {
        'num_users': len(unique_train_users),
        'num_items': len(unique_train_items),
        'num_ratings': len(unique_ratings),
        'train_size': len(train_u),
        'val_size': len(val_u),
        'test_size': len(test_u),
        'num_social_edges': sum(len(neighbors) for neighbors in social_adj_lists.values()) // 2,
        'ratings_list': ratings_list
    }

    return stats


def verify_pickle_file(pickle_path):
    """
    Load and verify the structure of a generated pickle file.

    Args:
        pickle_path: Path to the pickle file to verify
    """
    print(f"Verifying pickle file: {pickle_path}")

    with open(pickle_path, 'rb') as f:
        history_u_lists, history_ur_lists, history_v_lists, history_vr_lists, \
        train_u, train_v, train_r, val_u, val_v, val_r, test_u, test_v, test_r, \
        social_adj_lists, ratings_list = pickle.load(f)

    print(f"\nStructure verification:")
    print(f"  history_u_lists type: {type(history_u_lists)}, length: {len(history_u_lists)}")
    print(f"  history_ur_lists type: {type(history_ur_lists)}, length: {len(history_ur_lists)}")
    print(f"  history_v_lists type: {type(history_v_lists)}, length: {len(history_v_lists)}")
    print(f"  history_vr_lists type: {type(history_vr_lists)}, length: {len(history_vr_lists)}")
    print(f"  train_u length: {len(train_u)}")
    print(f"  train_v length: {len(train_v)}")
    print(f"  train_r length: {len(train_r)}")
    print(f"  val_u length: {len(val_u)}")
    print(f"  val_v length: {len(val_v)}")
    print(f"  val_r length: {len(val_r)}")
    print(f"  test_u length: {len(test_u)}")
    print(f"  test_v length: {len(test_v)}")
    print(f"  test_r length: {len(test_r)}")
    print(f"  social_adj_lists type: {type(social_adj_lists)}, length: {len(social_adj_lists)}")
    print(f"  ratings_list: {ratings_list}")

    # Show samples
    print(f"\nSample data:")
    sample_user = list(history_u_lists.keys())[0]
    print(f"  User {sample_user}:")
    print(f"    Items purchased: {history_u_lists[sample_user][:5]}...")
    print(f"    Rating indices: {history_ur_lists[sample_user][:5]}...")

    if sample_user in social_adj_lists:
        print(f"    Social neighbors: {list(social_adj_lists[sample_user])[:5]}")

    print(f"\n  Training samples (first 5):")
    for i in range(min(5, len(train_u))):
        print(f"    User {train_u[i]}, Item {train_v[i]}, Rating index {train_r[i]}")

    print(f"\n  Validation samples (first 5):")
    for i in range(min(5, len(val_u))):
        print(f"    User {val_u[i]}, Item {val_v[i]}, Rating index {val_r[i]}")

    print(f"\n  Test samples (first 5):")
    for i in range(min(5, len(test_u))):
        print(f"    User {test_u[i]}, Item {test_v[i]}, Rating index {test_r[i]}")


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description='Convert .mat files to GraphRec pickle format')
    parser.add_argument('--rating_file', type=str, required=True,
                       help='Path to _rating_with_timestamp.mat file')
    parser.add_argument('--trust_file', type=str, required=True,
                       help='Path to _trust.mat file')
    parser.add_argument('--output', type=str, required=True,
                       help='Output pickle file path')
    parser.add_argument('--user_percentage', type=float, default=100.0,
                       help='Percentage of users to sample (0-100, default: 100)')
    parser.add_argument('--train_split', type=float, default=0.8,
                       help='Train/test split ratio (0-1, default: 0.8)')
    parser.add_argument('--seed', type=int, default=42,
                       help='Random seed for reproducibility (default: 42)')
    parser.add_argument('--verify', action='store_true',
                       help='Verify the generated pickle file')

    args = parser.parse_args()

    # Validate arguments
    if not (0 < args.user_percentage <= 100):
        raise ValueError("user_percentage must be between 0 and 100")

    if not (0 < args.train_split < 1):
        raise ValueError("train_split must be between 0 and 1")

    # Create pickle file
    stats = create_pickle_from_mat(
        rating_file_path=args.rating_file,
        trust_file_path=args.trust_file,
        output_pickle_path=args.output,
        user_percentage=args.user_percentage,
        train_split=args.train_split,
        random_seed=args.seed
    )

    print("\n" + "="*50)
    print("Dataset Statistics:")
    print("="*50)
    for key, value in stats.items():
        print(f"{key}: {value}")

    # Verify if requested
    if args.verify:
        print("\n" + "="*50)
        verify_pickle_file(args.output)
