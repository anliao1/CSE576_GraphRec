# Data Preprocessing for GraphRec

This document describes how to use the `data_preprocessing.py` script to convert `.mat` files into pickle files compatible with the GraphRec model.

## Overview

The preprocessing script reads raw data from `.mat` files (rating and trust data) and generates pickle files with the same structure as the toy dataset used in GraphRec.

### Input Files

The script requires two `.mat` files:

1. **Rating file** (`*_rating_with_timestamp.mat`): N x 6 array with columns:
   - Column 0: user_id
   - Column 1: item_id
   - Column 2: category (not used)
   - Column 3: rating
   - Column 4: helpfulness
   - Column 5: timestamp

2. **Trust file** (`*_trust.mat`): N x 2 array with columns:
   - Column 0: user_id
   - Column 1: neighbor_user_id (social connection)

### Output Pickle File

The generated pickle file contains a tuple with 15 elements:

1. `history_u_lists`: dict {user_id: [list of item_ids purchased/interacted]}
2. `history_ur_lists`: dict {user_id: [list of rating indices for items in history_u_lists]}
3. `history_v_lists`: dict {item_id: [list of user_ids who interacted with item]}
4. `history_vr_lists`: dict {item_id: [list of rating indices for users in history_v_lists]}
5. `train_u`: list of user_ids for training
6. `train_v`: list of item_ids for training
7. `train_r`: list of rating indices for training
8. `val_u`: list of user_ids for validation
9. `val_v`: list of item_ids for validation
10. `val_r`: list of rating indices for validation
11. `test_u`: list of user_ids for testing
12. `test_v`: list of item_ids for testing
13. `test_r`: list of rating indices for testing
14. `social_adj_lists`: dict {user_id: set of neighbor user_ids}
15. `ratings_list`: dict {rating_value: rating_index}

## Usage

### Basic Usage

```bash
python3.11 data_preprocessing.py \
  --rating_file data/ciao_rating_with_timestamp.mat \
  --trust_file data/ciao_trust.mat \
  --output data/ciao_processed.pickle
```

### Advanced Usage with User Sampling

To generate a pickle file with only a subset of users (e.g., 10% for faster experimentation):

```bash
python3.11 data_preprocessing.py \
  --rating_file data/ciao_rating_with_timestamp.mat \
  --trust_file data/ciao_trust.mat \
  --output data/ciao_10percent.pickle \
  --user_percentage 10.0 \
  --train_split 0.8 \
  --seed 42 \
  --verify
```

### Command-Line Arguments

- `--rating_file`: **(Required)** Path to the `*_rating_with_timestamp.mat` file
- `--trust_file`: **(Required)** Path to the `*_trust.mat` file
- `--output`: **(Required)** Output path for the generated pickle file
- `--user_percentage`: Percentage of users to sample (0-100, default: 100)
  - Use smaller percentages for faster experimentation
  - Example: `--user_percentage 10.0` samples 10% of all users
- `--train_split`: Fraction of data for training (0-1, default: 0.8)
  - The remaining (1 - train_split) is split equally between validation and test
  - 0.8 means 80% training, 10% validation, 10% test
  - 0.6 means 60% training, 20% validation, 20% test
- `--seed`: Random seed for reproducibility (default: 42)
- `--verify`: Verify the generated pickle file and print statistics

## Examples

### Example 1: Process full Ciao dataset

```bash
python3.11 data_preprocessing.py \
  --rating_file data/ciao_rating_with_timestamp.mat \
  --trust_file data/ciao_trust.mat \
  --output data/ciao_full.pickle \
  --verify
```

### Example 2: Process 10% of Ciao with 80% train split

```bash
python3.11 data_preprocessing.py \
  --rating_file data/ciao_rating_with_timestamp.mat \
  --trust_file data/ciao_trust.mat \
  --output data/ciao_10percent.pickle \
  --user_percentage 10.0 \
  --train_split 0.8 \
  --seed 42 \
  --verify
```

This creates: 80% train, 10% validation, 10% test

### Example 3: Process 25% of Epinion with 60% train split

```bash
python3.11 data_preprocessing.py \
  --rating_file data/epinion_rating_with_timestamp.mat \
  --trust_file data/epinion_trust.mat \
  --output data/epinion_25percent.pickle \
  --user_percentage 25.0 \
  --train_split 0.6 \
  --seed 42 \
  --verify
```

This creates: 60% train, 20% validation, 20% test

### Example 4: Quick testing with 5% of users

```bash
python3.11 data_preprocessing.py \
  --rating_file data/ciao_rating_with_timestamp.mat \
  --trust_file data/ciao_trust.mat \
  --output data/ciao_5percent.pickle \
  --user_percentage 5.0 \
  --train_split 0.7 \
  --seed 123
```

This creates: 70% train, 15% validation, 15% test

## Output Statistics

When you run the script with `--verify`, you'll see statistics like:

```
Dataset Statistics:
==================================================
num_users: 737
num_items: 15266
num_ratings: 6
train_size: 21555
val_size: 1153
test_size: 1166
num_social_edges: 541
ratings_list: {0.0: 0, 1.0: 1, 2.0: 2, 3.0: 3, 4.0: 4, 5.0: 5}
```

## Using the Generated Pickle File

To use the generated pickle file in your GraphRec code:

```python
import pickle

# Load the data
with open('data/ciao_10percent.pickle', 'rb') as f:
    history_u_lists, history_ur_lists, history_v_lists, history_vr_lists, \
    train_u, train_v, train_r, val_u, val_v, val_r, test_u, test_v, test_r, \
    social_adj_lists, ratings_list = pickle.load(f)

# Now you can use these variables in your GraphRec model
num_users = len(history_u_lists)
num_items = len(history_v_lists)
num_ratings = len(ratings_list)

print(f"Users: {num_users}, Items: {num_items}, Ratings: {num_ratings}")
print(f"Train: {len(train_u)}, Val: {len(val_u)}, Test: {len(test_u)}")
```

## Data Preprocessing Details

### User Sampling

When `--user_percentage` is less than 100:
1. A random subset of users is selected
2. Only ratings from these users are included
3. Social connections are filtered to only include sampled users
4. User and item IDs are remapped to be 0-based and contiguous

### Train/Validation/Test Split

- The data is split into three sets: train, validation, and test
- With `train_split=X`, the split is: X% train, (1-X)/2% validation, (1-X)/2% test
- The split is performed randomly on all user-item interactions
- **IMPORTANT**: User and item IDs are remapped based on the **training set only**
- Validation and test samples are filtered to only include users/items that appeared in training
- This prevents cold-start problems where the model would need to predict for unseen users/items
- History dictionaries (`history_u_lists`, etc.) are built from **training data only**
- This ensures no data leakage from validation/test sets

**Note**: The validation and test set sizes may be smaller than expected because samples with users/items not in the training set are excluded. This is the correct behavior and matches the toy dataset structure.

**Recommended Splits**:
- For Ciao dataset: `--train_split 0.8` (80% train, 10% val, 10% test)
- For Epinion dataset: `--train_split 0.6` (60% train, 20% val, 20% test)

### Rating Index Mapping

Ratings are converted to indices for embedding lookups:
- `ratings_list` maps actual rating values to indices
- Example: `{0.5: 7, 1.0: 1, 1.5: 6, 2.0: 0, 2.5: 4, 3.0: 2, 3.5: 5, 4.0: 3}`
- The indices in `train_r` and `test_r` correspond to these mappings

### Social Graph

- Social connections are treated as **bidirectional** (undirected graph)
- If user A trusts user B, both `social_adj_lists[A]` and `social_adj_lists[B]` are updated

## Requirements

```bash
pip install scipy numpy
```

Or with specific Python version:

```bash
python3.11 -m pip install scipy numpy
```

## Notes

- The script automatically handles different key names in `.mat` files (e.g., 'rating' vs 'rating_with_timestamp')
- All user and item IDs are remapped to be 0-based and contiguous
- The random seed ensures reproducibility across runs
- Larger datasets may take several minutes to process
