#!/bin/bash
# ==========================================================
# GraphRec / GraphRec-Attr experiment runner (full datasets)
# ==========================================================
# Directory structure expected:
#   graphrec-add/
#     ├── data/
#     │     ├── ciao_full.pickle
#     │     ├── epinion_full.pickle
#     │     ├── toy_dataset.pickle  (optional)
#     ├── run_GraphRec_complete.py
#     ├── data_preprocessing.py
#     └── (this script)
#
# Logs are saved in logs/<dataset>_<config>.log
# ==========================================================

# Activate virtual environment
source ../venv/bin/activate

# Create log directory
mkdir -p logs

run_exp () {
    dataset=$1      # toy, ciao, epinion
    config=$2       # L0 (baseline) or L2 (attributes)
    fuse=$3         # concat or gate (empty for baseline)
    epochs=5
    batch_size=128

    log="logs/${dataset}_${config}${fuse:+_$fuse}.log"
    echo "===================================================="
    echo " Dataset: $dataset | Config: $config | Fuse: ${fuse:-none}"
    echo " Log: $log"
    echo "----------------------------------------------------"

    if [ "$config" == "L0" ]; then
        python run_GraphRec_complete.py \
            --dataset "$dataset" \
            --epochs "$epochs" \
            > "$log" 2>&1
    else
        python run_GraphRec_complete.py \
            --dataset "$dataset" \
            --use_attr \
            --fuse "$fuse" \
            --epochs "$epochs" \
            > "$log" 2>&1
    fi
}

# ==============================
#   Run experiments
# ==============================

# Toy dataset (if exists)
#if [ -f "data/toy_dataset.pickle" ]; then
    #run_exp toy L0 "" 
    #run_exp toy L2 concat 
    #run_exp toy L2 gate 
#fi

# Ciao dataset (full)
run_exp ciao L0 "" 
run_exp ciao L2 concat 
run_exp ciao L2 gate 

# Epinion dataset (full)
run_exp epinion L0 "" 
run_exp epinion L2 concat 
run_exp epinion L2 gate 

echo "===================================================="
echo " All GraphRec / GraphRec-Attr experiments completed!"
echo " Logs saved in ./logs/"
echo "===================================================="
