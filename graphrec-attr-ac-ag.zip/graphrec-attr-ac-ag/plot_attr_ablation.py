import numpy as np
import matplotlib.pyplot as plt

"""
GraphRec-Attr Ablation Results (Ciao & Epinions)

Variants:
- GraphRec-SN          : Social-graph component removed.
- GraphRec-Attr-Concat : Attribute embeddings concatenated into user/item features.
- GraphRec-Attr-Gate   : Attribute embeddings integrated via gating.
- GraphRec-Baseline    : Full model with all components.
"""

methods = [
    "SN",
    "Attr-Concat",
    "Attr-Gate",
    "Baseline",
]

# --- Metrics ---
ciao_rmse = [0.9864, 0.9827, 0.9849, 0.9817]
ciao_mae  = [0.7490, 0.7428, 0.7424, 0.7371]

ep_rmse   = [1.0634, 1.0677, 1.0686, 1.0658]
ep_mae    = [0.8232, 0.8247, 0.7918, 0.8207]

colors = ["#4C72B0", "#55A868", "#C44E52", "#8172B2"]  # distinct palette

def plot_bar(ax, data, ylabel, title, ylim=None):
    x = np.arange(len(methods))
    bars = ax.bar(x, data, color=colors, width=0.6, edgecolor='black', linewidth=0.8)
    ax.set_xticks(x)
    ax.set_xticklabels(methods, rotation=15, ha="right", fontsize=9)
    ax.set_ylabel(ylabel)
    ax.set_title(title, fontsize=11)
    if ylim:
        ax.set_ylim(ylim)
    for bar in bars:
        height = bar.get_height()
        ax.annotate(f"{height:.3f}", 
                    xy=(bar.get_x() + bar.get_width() / 2, height),
                    xytext=(0, 3), textcoords="offset points",
                    ha='center', va='bottom', fontsize=8)

# --- Figure ---
fig, axes = plt.subplots(2, 2, figsize=(9, 6))
(ax1, ax2), (ax3, ax4) = axes

# auto y-axis ranges for better spacing
plot_bar(ax1, ciao_rmse, "RMSE", "Ciao - RMSE", ylim=(0.97, 1.00))
plot_bar(ax2, ep_rmse,   "RMSE", "Epinions - RMSE", ylim=(1.06, 1.07))
plot_bar(ax3, ciao_mae,  "MAE",  "Ciao - MAE",  ylim=(0.73, 0.76))
plot_bar(ax4, ep_mae,    "MAE",  "Epinions - MAE",  ylim=(0.78, 0.83))

fig.tight_layout()
plt.savefig("graphrec_attr_ablation_v2.png", dpi=300, bbox_inches="tight")
plt.show()
